PREFIX = "!!"
TOKEN = ""